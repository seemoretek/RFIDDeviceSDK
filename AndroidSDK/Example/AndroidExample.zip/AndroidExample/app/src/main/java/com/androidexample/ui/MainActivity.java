package com.androidexample.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.androidexample.R;
import com.androidexample.example.AdvanceRFIDInventoryExample;
import com.androidexample.example.BaseRFIDInventoryExample;
import com.androidexample.example.RFIDReadTagExample;
import com.androidexample.example.RFIDWriteTagExample;

public class MainActivity extends AppCompatActivity {

    EditText linkEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        linkEditText = findViewById(R.id.et_link);
    }

    private String getLink() {
        return linkEditText.getText().toString();
    }

    public void onClickBasicInventory(View view) {
        new Thread(() -> {
            BaseRFIDInventoryExample.test(getLink());
        }).start();
    }

    public void onClickAdvanceInventory(View view) {
        new Thread(() -> {
            AdvanceRFIDInventoryExample.test(getLink());
        }).start();
    }

    public void onClickReadTag(View view) {
        new Thread(() -> {
            RFIDReadTagExample.test(getLink());
        }).start();
    }

    public void onClickWriteTag(View view) {
        new Thread(() -> {
            RFIDWriteTagExample.test(getLink());
        }).start();
    }
}